//
//  TokenManager.h
//  OAuth_Demo
//
//  Created by InnoeriOS1 on 2017/2/15.
//
//

#import <Foundation/Foundation.h>

@interface TokenInfo : NSObject

/** <#code#> */
@property (nonatomic, copy) NSString *access_token;

/** <#code#> */
@property (nonatomic, copy) NSString *token_type;

/** <#code#> */
@property (nonatomic, copy) NSString *expires_in;

@end


@interface TokenManager : NSObject

/** <#code#> */
@property (nonatomic, strong) TokenInfo *mToken;

+ (instancetype)sharedInstance;

-(void)tokenWithUrl:(NSString *)url params:(NSDictionary *)params success:(void (^)(TokenInfo *token))success failure:(void (^)(NSError *error))failure;

@end
