//
//  NetWorkingManager.m
//  ATOM
//
//  Created by InnoeriOS1 on 2016/12/28.
//  Copyright © 2016年 KingY. All rights reserved.
//

#import "NetWorkingManager.h"
#import "AFNetworking/AFNetworking.h"
#import "WHC_DataModel.h"
#import "SVPUtil.h"
#import "NSObject+WHC_Model.h"
#import "TokenManager.h"
@interface DataResults : NSObject

/** <#code#> */
@property (nonatomic, copy) NSString *Msg;

/** no */
@property (nonatomic, copy) NSString *Status;

/** <#code#> */
@property (nonatomic, strong) NSArray *Data;

@end

@implementation  DataResults
@end

@implementation NetWorkingManager



+(void)postWithUrl:(NSString *)url param:(id)param resultClass:(Class)resultClass isProgress:(BOOL)isProgress tokenExpire:(void(^)())tokenExpire success:(void (^)(NSArray *))success  failure:(void (^)(NSError *))failure
{
    if (isProgress)
        [SVPUtil showProgressMessage:nil];
    else
        [SVPUtil dismissHUD];
    
    NSDictionary *dictParam;
    if ([param isKindOfClass:[NSDictionary class]]) {
        dictParam = param;
    }else
    {
        dictParam = [param whc_Dictionary];
    }
    
    [NetWorkingManager postWithUrl:url param:dictParam success:^(DataResults *result) {
        if (success) {
            if (isProgress) {
                if ([result.Status isEqualToString:@"1"]) {
                    if (result.Msg.length > 0) {
                        [SVPUtil showSuccessMessage:result.Msg];
                    }else
                    {
                        [SVPUtil dismissHUD];
                    }
                    
                    NSArray *array = [[resultClass class] whc_ModelWithJson:result.Data];
                    success(array);
                   
                }else if ([result.Status isEqualToString:@"tokenF"])
                {
                    //token失效
                    tokenExpire();
                }
                else
                {
                    [SVPUtil showInfoMessage:result.Msg];
                    success(nil);
                }
            }
        }
    } failure:^(NSError *error) {
        if (failure) {
            [SVPUtil showErrorMessage:[NSString stringWithFormat:@"ERROR:%ld",(long)error.code]];
            failure(error);
        }
    }];

}

+(void)postWithUrl:(NSString *)url param:(id)param resultClass:(Class)resultClass success:(void (^)(NSArray *results))success failure:(void (^)(NSError *))failure
{
    NSDictionary *dictParam = [param whc_Dictionary];
    
    [NetWorkingManager postWithUrl:url param:dictParam success:^(DataResults *result) {
        if (result) {
            if ([result.Status isEqualToString:@"1"]) {
                [SVPUtil dismissHUD];
                NSArray *array = [WHC_DataModel dataModelWithArray:result.Data className:[resultClass class]];
                success(array);
            }else
            {
                [SVPUtil showInfoMessage:result.Msg];
                success(nil);
            }
        }
    } failure:^(NSError *error) {
        if (failure) {
            failure(error);
        }
    }];
    
}

+(void)postWithUrl:(NSString *)url param:(NSDictionary *)param success:(void (^)(id))success failure:(void (^)(NSError *))failure
{
    
    [NetWorkingManager post:url params:param success:^(id result) {
        if (success) {
            NSString *str = [[NSString alloc]initWithData:result encoding:NSUTF8StringEncoding];
            
            DataResults *resultObj = [DataResults whc_ModelWithJson:result];
            success(resultObj);
        }
    } failure:^(NSError *error) {
        if (failure) {
            failure(error);
        }
    }];
}

+(void)post:(NSString *)url params:(NSDictionary *)params success:(void (^)(id))success failure:(void (^)(NSError *))failure
{
    AFHTTPSessionManager *session = [AFHTTPSessionManager manager];
    session.requestSerializer = [AFHTTPRequestSerializer serializer];
    
    [session.requestSerializer setValue:[NSString stringWithFormat:@"%@ %@",[TokenManager sharedInstance].mToken.token_type,[TokenManager sharedInstance].mToken.access_token] forHTTPHeaderField:@"Authorization"];    session.responseSerializer = [AFHTTPResponseSerializer serializer];
    session.requestSerializer.timeoutInterval = 30;
    
    [session.responseSerializer setAcceptableContentTypes:[NSSet setWithObjects:@"application/json",@"text/html",@"text/javascript",@"text/xml",nil]];
    [session POST:url parameters:params progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        success(responseObject);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        failure(error);
    }];
}

//fileName则是直接上传上去的图片， 注意一定要加 .jpg或者.png，（这个根据你得到这个imgData是通过jepg还是png的方式来获取决定）
+ (void)postDataWithUrl:(NSString *)url
                 images:(NSArray *)images
             imageNames:(NSArray *)imageNames
             folderName:(NSString *)folderName
              isProress:(BOOL)isProgress
                 params:(NSDictionary *)params
               progress:(void (^)(float pro))progress
                success:(void (^)(id responseObject))success
                failure:(void (^)( NSError *error))failure
{
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFHTTPRequestSerializer serializer];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    manager.requestSerializer.timeoutInterval = 30;
    [manager.responseSerializer setAcceptableContentTypes:[NSSet setWithObjects:@"application/json",@"text/html",@"text/javascript",@"text/xml",@"image/jpeg",@"image/png",nil]];
    [manager POST:url parameters:params constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
        if (images.count == 0) {
            if (isProgress) {
                [SVPUtil showInfoMessage:@"No Image"];
            }
            failure(nil);
            return ;
        }else{
            if (isProgress) {
                [SVPUtil showProgressMessage:@""];
            }
            for (NSInteger i = 0; i<images.count; i++) {
                NSString *fileName =imageNames[i];
                NSData *imageData = UIImageJPEGRepresentation(images[i], 0.75);
                [formData appendPartWithFileData:imageData name:folderName fileName:fileName mimeType:@"image/jpeg"];
            }
        }
    } progress:^(NSProgress * _Nonnull uploadProgress) {
        NSString *prores = [NSString stringWithFormat:@"%lld",uploadProgress.completedUnitCount/uploadProgress.totalUnitCount];
        if (progress) {
            progress([prores floatValue]);
        }
        
        if (isProgress) {
            if ([prores floatValue] >= 1.0) {
                [SVPUtil dismissHUD];
            }else
            {
                [SVPUtil showProgressMessageWithNotAllowTouch:prores];
            }
        }
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:nil];
        if (isProgress) {
            [SVPUtil showSuccessMessage:nil];
        }

        if (success) {
            success(dic);
        }
        
    }failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        if (isProgress) {
            [SVPUtil showErrorMessage:[NSString stringWithFormat:@"Error:%ld",error.code]];
        }

        if (failure) {
            failure(error);
        }
    }];
    
    
}




@end
