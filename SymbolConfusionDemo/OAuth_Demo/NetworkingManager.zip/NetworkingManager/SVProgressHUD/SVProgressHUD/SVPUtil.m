//
//  SVPUtil.m
//  OAuth_Demo
//
//  Created by InnoeriOS1 on 2017/2/15.
//
//

#import "SVPUtil.h"
#import "SVProgressHUD.h"
#define WHITECOLOR                        [UIColor whiteColor]
#define RGB_A(a,b,c,d)                      [UIColor colorWithRed:a/255.0 green:b/255.0 blue:c/255.0 alpha:d]

@implementation SVPUtil
+ (void)showSuccessMessage:(NSString *)message
{
    [SVProgressHUD setForegroundColor:WHITECOLOR];
    [SVProgressHUD setBackgroundColor:RGB_A(254.0,190.0,16.0,0.7)];
    [SVProgressHUD showSuccessWithStatus:message];
}

+ (void)showErrorMessage:(NSString *)message
{
    [SVProgressHUD setForegroundColor:WHITECOLOR];
    [SVProgressHUD setBackgroundColor:RGB_A(254.0,190.0,16.0,0.7)];
    [SVProgressHUD showErrorWithStatus:message];
}

+ (void)showProgressMessage:(NSString *) message
{
    [SVProgressHUD setForegroundColor:WHITECOLOR];
    [SVProgressHUD setBackgroundColor:RGB_A(254.0,190.0,16.0,0.7)];
    [SVProgressHUD showWithStatus:message];
}

+ (void)showProgressMessageWithNotAllowTouch:(NSString *)message
{
    [SVProgressHUD setForegroundColor:WHITECOLOR];
    [SVProgressHUD setBackgroundColor:RGB_A(254.0,190.0,16.0,0.7)];
    [SVProgressHUD showWithStatus:message maskType:SVProgressHUDMaskTypeClear];
}

+ (void)showInfoMessage:(NSString *)message
{
    [SVProgressHUD setForegroundColor:WHITECOLOR];
    [SVProgressHUD setBackgroundColor:RGB_A(254.0,190.0,16.0,0.7)];
    [SVProgressHUD showInfoWithStatus:message];
}

+ (void)dismissHUD
{
    [SVProgressHUD dismiss];
}

@end
