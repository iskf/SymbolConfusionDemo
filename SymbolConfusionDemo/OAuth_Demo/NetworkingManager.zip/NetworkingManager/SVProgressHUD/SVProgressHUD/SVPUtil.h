//
//  SVPUtil.h
//  OAuth_Demo
//
//  Created by InnoeriOS1 on 2017/2/15.
//
//

#import <Foundation/Foundation.h>

@interface SVPUtil : NSObject
//弹出操作错误信息提示框
+ (void)showErrorMessage:(NSString *)message;

//弹出操作成功信息提示框
+ (void)showSuccessMessage:(NSString *)message;

//弹出加载提示框
+ (void)showProgressMessage:(NSString *) message;

//弹出加载提示框,此时屏幕不响应用户点击事件
+ (void)showProgressMessageWithNotAllowTouch:(NSString *)message;

//弹出信息提示框
+ (void)showInfoMessage:(NSString *)message;

//取消弹出框
+ (void)dismissHUD;
@end
