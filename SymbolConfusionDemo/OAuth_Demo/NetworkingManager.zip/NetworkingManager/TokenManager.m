//
//  TokenManager.m
//  OAuth_Demo
//
//  Created by InnoeriOS1 on 2017/2/15.
//
//

#import "TokenManager.h"
#import "AFNetworking/AFNetworking.h"
#import "AESCipher.h"
#import "NSObject+WHC_Model.h"
#define TOKENHEADER [NSString stringWithFormat:@"%@ %@",@"CLIENT",[self stringWithFormat:@"yyyy-MM-dd HH:mm:ss" date:[NSDate new]]]
@implementation TokenInfo


@end

@implementation TokenManager

+ (instancetype)sharedInstance {
    static TokenManager *instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[TokenManager alloc] init];
    });
    return instance;
}
-(void)tokenWithUrl:(NSString *)url params:(NSDictionary *)params success:(void (^)(TokenInfo *))success failure:(void (^)(NSError *))failure
{
    AFHTTPSessionManager *session = [AFHTTPSessionManager manager];
    session.requestSerializer = [AFHTTPRequestSerializer serializer];
    
    //header
    NSString *callFrom =[AESCipher encryptAES:TOKENHEADER key:@"INNOWAYS API0000"];
    [session.requestSerializer setValue:callFrom forHTTPHeaderField:@"CallFrom"];
    
    session.requestSerializer.timeoutInterval = 30;
    
    session.responseSerializer = [AFHTTPResponseSerializer serializer];
    [session.responseSerializer setAcceptableContentTypes:[NSSet setWithObjects:@"application/json",@"text/html",@"text/javascript",@"text/xml",nil]];
    [session POST:url parameters:params progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        TokenInfo *token = [TokenInfo whc_ModelWithJson:responseObject];
        self.mToken = token;
        success(token);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        failure(error);
    }];
}

- (NSString *)stringWithFormat:(NSString *)format date:(NSDate *)date {
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:format];
    [formatter setLocale:[NSLocale currentLocale]];
    return [formatter stringFromDate:date];
}

@end
